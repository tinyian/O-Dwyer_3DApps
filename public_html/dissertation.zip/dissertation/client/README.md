# Immersify - Three.js Test

- Inspired and created from [full tutorial](https://youtu.be/Q7AOvWpIVHU) on YouTube to achieve scrollable 3D animation

## Ian O'Dwyer, 2023
